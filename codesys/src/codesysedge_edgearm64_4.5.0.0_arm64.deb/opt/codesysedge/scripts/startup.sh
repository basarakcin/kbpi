#!/bin/bash

term() {
    echo "[    INFO] $0: Shuting down codesysedge..."
    kill -15 $pid
    wait $pid
}

# Only start this script if we are in a docker-container
if [ ! -f /.dockerenv ]; then
    echo "[   ERROR] $0: Non docker-enviroment detected. Not running script."
    exit 1
fi

# At runtimestart we expect /conf/codesysedge to be present
if [ ! -d /conf/codesysedge/ ]; then
    echo "[   ERROR] $0: Missing /conf/codesysedge. Call docker run with volume options:" 
    echo
    echo "-v ~/<mountingpoint>/conf/codesysedge/:/conf/codesysedge/"
    echo "For example:"
    echo "docker run -d -v ~/dockerMountEdge/conf/codesysedge/:/conf/codesysedge/ -p 1217:1217/tcp codesysedge_edgeamd64:4.5.0.0"
    exit 1
fi 

DEBUG=$1

echo "[    INFO] $0: Initialize /conf directory used by docker mounts"

#check if initialization was already done. 
if [ ! -f /conf/codesysedge/.docker_initialized ]; then 
    #not yet initialized, copy original files
    echo "[    INFO] $0: Initialize /conf/codesysedge with files from /etc"
    cp -f /etc/GatewayvControl.cfg /conf/codesysedge/
    #touch marker file to avoid overwriteing existing files
    touch /conf/codesysedge/.docker_initialized
fi     

cd /var/opt/codesysedge

echo "[    INFO] $0: To run Edge-Gateway in debug mode, use docker run with flag -d at the end"

if [ "$1" = "-d" ]; then
    DEBUG=-d
else 
    DEBUG=""
fi

echo "[    INFO] $0: Codesysedge starting"
/opt/codesysedge/bin/codesysedge.bin /conf/codesysedge/GatewayvControl.cfg $DEBUG &

pid=($!)
trap term SIGTERM
trap term SIGINT
wait "$pid"
